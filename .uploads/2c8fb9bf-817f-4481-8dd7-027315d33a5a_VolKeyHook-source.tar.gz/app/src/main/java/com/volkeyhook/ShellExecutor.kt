package com.volkeyhook

import android.content.Context
import android.widget.Toast

/**
 * Executes a shell command as root using the su binary (Magisk/KernelSU).
 *
 * Used both for the in-app "test run" button and by [ActionExecutor] when a
 * volume-key double-click is configured to run a shell command.
 */
object ShellExecutor {

    data class Result(val exitCode: Int, val output: String)

    fun runAsRoot(command: String): Result {
        if (command.isBlank()) return Result(-1, "empty command")
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val out = process.inputStream.bufferedReader().use { it.readText() }
            val err = process.errorStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            Result(code, if (out.isNotBlank()) out else err)
        } catch (t: Throwable) {
            Result(-1, t.localizedMessage ?: t.toString())
        }
    }

    /** Convenience: runs [command] and toasts a short summary. */
    fun runAndToast(ctx: Context, command: String) {
        Thread {
            val r = runAsRoot(command)
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    ctx,
                    "exit=${r.exitCode}\n${r.output.take(200)}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }
}
